package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.entity.*
import com.example.ui.components.GoldButton
import com.example.ui.theme.*
import java.util.UUID

@Composable
fun AdminScreen(
    stats: Map<String, Any>,
    challenges: List<ChallengeEntity>,
    users: List<UserEntity>,
    reports: List<ReportEntity>,
    onAddChallenge: (ChallengeEntity) -> Unit,
    onDeleteChallenge: (String) -> Unit,
    onAddReward: (RewardItemEntity) -> Unit,
    onToggleSuspendUser: (UserEntity) -> Unit,
    onRefreshStats: () -> Unit,
    onBack: () -> Unit
) {
    var selectedSection by remember { mutableStateOf("STATS") }
    var showAddChallengeDialog by remember { mutableStateOf(false) }
    var showAddRewardDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        onRefreshStats()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavyDark)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(NavyCard)
                    .testTag("admin_back_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.ArrowForward,
                    contentDescription = "رجوع",
                    tint = GoldPrimary
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "لوحة الإدارة والتحكم", color = GoldPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Surface(shape = RoundedCornerShape(4.dp), color = GoldDark) {
                        Text(text = "ADMIN", color = DeepNavyDark, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    }
                }
                Text(text = "إدارة التحديات، المكافآت، الحسابات، وإحصائيات النظام", color = TextMuted, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Navigation Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                "STATS" to "الإحصائيات",
                "CHALLENGES" to "التحديات",
                "USERS" to "المستخدمين",
                "REPORTS" to "البلاغات"
            ).forEach { (key, label) ->
                val isSelected = selectedSection == key
                Surface(
                    onClick = { selectedSection = key },
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) GoldPrimary else NavyCard,
                    border = BorderStroke(1.dp, if (isSelected) GoldPrimary else NavyBorder),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = label,
                        color = if (isSelected) DeepNavyDark else TextWhite,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(vertical = 8.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Section Content
        when (selectedSection) {
            "STATS" -> {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = NavySurface),
                            border = BorderStroke(1.dp, GoldSecondary.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = "📊 مؤشرات النظام الإجمالية", color = GoldLight, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(14.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    StatCard("المستخدمين", "${stats["totalUsers"] ?: 0}", Icons.Filled.People, Modifier.weight(1f))
                                    StatCard("مشاهدات الإعلانات", "${stats["totalAdsWatched"] ?: 0}", Icons.Filled.PlayCircle, Modifier.weight(1f))
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    StatCard("النقاط المكتسبة", "${stats["totalEarned"] ?: 0}", Icons.Filled.Stars, Modifier.weight(1f), tint = SuccessGreen)
                                    StatCard("النقاط المصروفة", "${stats["totalSpent"] ?: 0}", Icons.Filled.ShoppingCart, Modifier.weight(1f), tint = GoldPrimary)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = NavyCard),
                            border = BorderStroke(1.dp, NavyBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = "إجراءات سريعة للمسؤول", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(12.dp))

                                GoldButton(
                                    text = "إضافة تحدٍ جديد",
                                    onClick = { showAddChallengeDialog = true },
                                    icon = Icons.Filled.Add,
                                    modifier = Modifier.fillMaxWidth(),
                                    testTag = "admin_add_challenge_button"
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedButton(
                                    onClick = { showAddRewardDialog = true },
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, GoldSecondary),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Filled.AddShoppingCart, contentDescription = null, tint = GoldSecondary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("إضافة مكافأة جديدة للمتجر", color = GoldSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            "CHALLENGES" -> {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "قائمة التحديات (${challenges.size})", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { showAddChallengeDialog = true }) {
                            Icon(Icons.Filled.Add, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة", color = GoldPrimary, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(challenges, key = { it.id }) { c ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = NavySurface),
                                border = BorderStroke(1.dp, NavyBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = c.title, color = GoldLight, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Text(text = "${c.type} • +${c.coinsReward} GANI COINS", color = TextMuted, fontSize = 11.sp)
                                    }
                                    IconButton(onClick = { onDeleteChallenge(c.id) }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = ErrorRed, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "USERS" -> {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(users, key = { it.id }) { u ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = NavySurface),
                            border = BorderStroke(1.dp, if (u.isSuspended) ErrorRed else NavyBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(text = u.username, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        if (u.isAdmin) {
                                            Surface(shape = RoundedCornerShape(4.dp), color = GoldPrimary) {
                                                Text(text = "مدير", color = DeepNavyDark, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                                            }
                                        }
                                        if (u.isSuspended) {
                                            Surface(shape = RoundedCornerShape(4.dp), color = ErrorRed) {
                                                Text(text = "موقوف", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                                            }
                                        }
                                    }
                                    Text(text = "${u.ganiCoins} نقاط • المستوى: ${u.level}", color = TextMuted, fontSize = 11.sp)
                                }

                                if (!u.isAdmin) {
                                    OutlinedButton(
                                        onClick = { onToggleSuspendUser(u) },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = if (u.isSuspended) SuccessGreen else ErrorRed
                                        ),
                                        border = BorderStroke(1.dp, if (u.isSuspended) SuccessGreen else ErrorRed),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(if (u.isSuspended) "تفعيل" else "إيقاف", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "REPORTS" -> {
                if (reports.isEmpty()) {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(text = "لا توجد بلاغات أو رسائل جديدة حالياً", color = TextMuted, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(reports, key = { it.id }) { rep ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = NavySurface),
                                border = BorderStroke(1.dp, NavyBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = rep.subject, color = GoldLight, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                        Text(text = rep.username, color = TextMuted, fontSize = 11.sp)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(text = rep.message, color = TextWhite, fontSize = 12.sp, lineHeight = 16.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Challenge Dialog
    if (showAddChallengeDialog) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var coinsStr by remember { mutableStateOf("30") }
        var type by remember { mutableStateOf("DAILY") }
        var category by remember { mutableStateOf("GENERAL") }

        Dialog(onDismissRequest = { showAddChallengeDialog = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = BorderStroke(1.dp, GoldPrimary),
                modifier = Modifier.padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("إضافة تحدٍ جديد", color = GoldLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("عنوان التحدي") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("الوصف") },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = coinsStr,
                        onValueChange = { coinsStr = it },
                        label = { Text("نقاط المكافأة") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    GoldButton(
                        text = "حفظ وإضافة التحدي",
                        onClick = {
                            if (title.isNotBlank()) {
                                onAddChallenge(
                                    ChallengeEntity(
                                        id = "custom_${UUID.randomUUID()}",
                                        type = type,
                                        title = title,
                                        description = description,
                                        coinsReward = coinsStr.toLongOrNull() ?: 30L,
                                        xpReward = 40L,
                                        category = category,
                                        isBuiltIn = false
                                    )
                                )
                                showAddChallengeDialog = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    TextButton(onClick = { showAddChallengeDialog = false }) {
                        Text("إلغاء", color = TextMuted)
                    }
                }
            }
        }
    }

    // Add Reward Dialog
    if (showAddRewardDialog) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var priceStr by remember { mutableStateOf("150") }

        Dialog(onDismissRequest = { showAddRewardDialog = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NavySurface),
                border = BorderStroke(1.dp, GoldPrimary),
                modifier = Modifier.padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("إضافة مكافأة جديدة للمتجر", color = GoldLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("اسم المكافأة أو اللقب") },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("الوصف") },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text("السعر بنقاط GANI COINS") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    GoldButton(
                        text = "نشر في المتجر",
                        onClick = {
                            if (title.isNotBlank()) {
                                onAddReward(
                                    RewardItemEntity(
                                        id = "r_custom_${UUID.randomUUID()}",
                                        type = "TITLE",
                                        title = title,
                                        description = description,
                                        priceCoins = priceStr.toLongOrNull() ?: 150L,
                                        iconName = "stars",
                                        valueKey = "custom_title_${System.currentTimeMillis()}"
                                    )
                                )
                                showAddRewardDialog = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    TextButton(onClick = { showAddRewardDialog = false }) {
                        Text("إلغاء", color = TextMuted)
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    tint: Color = GoldPrimary
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = NavyCard,
        border = BorderStroke(1.dp, NavyBorder),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
            Column {
                Text(text = value, color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(text = title, color = TextMuted, fontSize = 10.sp)
            }
        }
    }
}
